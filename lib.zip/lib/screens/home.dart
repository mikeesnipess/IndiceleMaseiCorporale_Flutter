import 'package:task1/constants/app_constants.dart';
import 'package:task1/widgets/left_bar.dart';
import 'package:task1/widgets/right_bar.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget{
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>{
  TextEditingController _inaltimeController = TextEditingController();
  TextEditingController _greutateController = TextEditingController();
  double _imcResult=0;
  String _textResult = "";
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "IMC Calculator",
          style: TextStyle(color:accentHexColor,fontWeight: FontWeight.w300),
        ),
      backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
      ),
      backgroundColor: mainHexColor,
      body:SingleChildScrollView(
        child:Column(
          children: [
            SizedBox(height: 20,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  width: 130,
                  child: TextField(
                    controller: _inaltimeController,
                    style: TextStyle(
                      fontSize: 42,
                      fontWeight: FontWeight.w300,
                      color: accentHexColor
                    ),
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: "Inaltime",
                      hintStyle:TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w300,
                        color:Colors.white.withOpacity(.8)
                      )
                    ),
                  )
                ),//inaltime
                Container(
                    width: 130,
                    child: TextField(
                      controller: _greutateController,
                      style: TextStyle(
                          fontSize: 42,
                          fontWeight: FontWeight.w300,
                          color: accentHexColor
                      ),
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Greutate",
                          hintStyle:TextStyle(
                              fontSize: 30,
                              fontWeight: FontWeight.w300,
                              color:Colors.white.withOpacity(.8)
                          )
                      ),
                    )
                ) //greutate
              ],
            ),
            SizedBox(height: 30,),
            GestureDetector(
           onTap: (){
            double _i = double.parse(_inaltimeController.text);
            double _g = double.parse(_greutateController.text);
            setState(() {

              _imcResult=_g/(_i*_i);

              if(_imcResult>25){
                _textResult="Greutate excesiva";
              }else if(_imcResult >= 18.5 && _imcResult <=25){
                _textResult ="Greutate normala";
              }else{
                _textResult="Greutate mica";
              }
            });
           },
              child:Container(
              child: Text("Calculate",style:TextStyle(fontSize: 22,fontWeight: FontWeight.bold,color: accentHexColor),),
              ),
            ),
            SizedBox(height: 50,),
            Container(
              child: Text(_imcResult.toStringAsFixed(2), style: TextStyle(fontSize: 90, color: accentHexColor),),
            ),
            SizedBox(height: 30,),
            Visibility(
              visible: _textResult.isNotEmpty,
              child: Container(
              child: Text(_textResult, style: TextStyle(fontSize:32,fontWeight: FontWeight.w400,color: accentHexColor),),
            ),),
            SizedBox(height: 10,),
            LeftBar(barWidth: 40),
            SizedBox(height: 20,),
            LeftBar(barWidth: 70),
            SizedBox(height: 20,),
            LeftBar(barWidth: 20),
            SizedBox(height: 20,),
            RightBar(barWidth: 20),
            SizedBox(height: 50,),
            RightBar(barWidth: 70),
          ],
        )
      )
    );
  }
}