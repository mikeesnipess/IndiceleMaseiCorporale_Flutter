import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

final Color mainHexColor = HexColor("#000000");
final Color accentHexColor = HexColor("#8fce00");